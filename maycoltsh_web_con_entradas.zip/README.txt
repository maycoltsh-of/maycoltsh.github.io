MAYCOL T.SH - ESTRUCTURA DE PÁGINAS

Sube toda la carpeta/archivos al alojamiento de tu dominio.

Rutas:
https://maycoltsh.com/
https://maycoltsh.com/noticias/
https://maycoltsh.com/momentosxd/
https://maycoltsh.com/videos/
https://maycoltsh.com/redes/

Cada carpeta contiene su propio index.html, por eso el alojamiento puede mostrar una URL limpia.

IMPORTANTE:
- En GitHub Pages, si usas un dominio personalizado, estas rutas funcionan como carpetas.
- En otros alojamientos también suelen funcionar directamente.
- Para crear nuevas entradas puedes crear otra carpeta, por ejemplo:
  /blog/index.html
  /proyectos/index.html
  /contacto/index.html

La sección de noticias usa un RSS mediante rss2json.com; si el navegador o el servicio bloquea la consulta, aparecerá un mensaje de error.
